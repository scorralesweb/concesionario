<template>
  <NuxtLayout name="vans">
    <VansDescubri></VansDescubri>
    <VansLegal></VansLegal>
  </NuxtLayout>
</template>

<style scope>
@import "~/assets/css/vans/modelos.css";
</style>
