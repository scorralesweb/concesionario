<template>
  <!-- Aviso legal y notas-->
  <div id="notaLegal">
    <div class="pageWidth">
      <p><strong>Aviso legal y notas:</strong></p>
      <p>Las imágenes publicadas en este sitio son de carácter ilustrativo y con fin publicitario. En ningún caso deben reputarse y/o interpretarse como contractuales. Consulte especificaciones técnicas y equipamiento de cada vehículo en la Red de Concesionarios Oficiales Mercedes-Benz. Mercedes-Benz Argentina S.A.U. se reserva el derecho de modificar especificaciones y/o nivel de equipamiento sin previo aviso y sin incurrir en ninguna obligación.</p>
    </div>
  </div>
</template>

<script setup lang="ts">
const appConfig = useAppConfig();
</script>

<style scope>
@import "~/assets/css/camiones/legal.css";
</style>
