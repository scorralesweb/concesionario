<template>
  <div id="descubri">
    <!-- Nuestros modelos -->
    <div class="pageWidth">
      <h2>Nuestros modelos</h2>
      <ul>
        <!-- Card -->
        <li>
          <VansCardsModeloCard
            titulo="Sprinter"
            modelo="Sprinter Furgón"
            miniatura="sprinter-furgon.jpg"
            link="/vans/modelos/sprinter-furgon"
          >
          </VansCardsModeloCard>
        </li>

        <!-- Card -->
        <li>
          <VansCardsModeloCard
            titulo="Sprinter"
            modelo="Sprinter Mixto"
            miniatura="sprinter-mixto.jpg"
            link="/vans/modelos/sprinter-mixto"
          >
          </VansCardsModeloCard>
        </li>

        <!-- Card -->
        <li>
          <VansCardsModeloCard
            titulo="Sprinter"
            modelo="Sprinter Combi"
            miniatura="sprinter-combi.jpg"
            link="/vans/modelos/sprinter-combi"
          >
          </VansCardsModeloCard>
        </li>

        <!-- Card -->
        <li>
          <VansCardsModeloCard
            titulo="Sprinter"
            modelo="Sprinter Chasis"
            miniatura="sprinter-chasis.jpg"
            link="/vans/modelos/sprinter-chasis"
          >
          </VansCardsModeloCard>
        </li>

        <!-- Card -->
        <li>
          <VansCardsModeloCard
            titulo="Vito"
            modelo="Vito Furgón"
            miniatura="vito-furgon.jpg"
            link="/vans/modelos/vito-furgon"
          >
          </VansCardsModeloCard>
        </li>

        <!-- Card -->
        <li>
          <VansCardsModeloCard
            titulo="Vito"
            modelo="Vito Mixto Plus"
            miniatura="vito-mixto-plus.jpg"
            link="/vans/modelos/vito-mixto-plus"
          >
          </VansCardsModeloCard>
        </li>
      </ul>
    </div>
  </div>
</template>

<style scope>
@import "~/assets/css/vans/descubri.css";
</style>
