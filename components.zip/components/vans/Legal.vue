<template>
  <!-- Aviso legal y notas-->
  <div id="notaLegal">
    <div class="pageWidth">
      <p><strong>Aviso legal y notas:</strong></p>
      <p>Las imágenes publicadas en este sitio son de carácter ilustrativo. En ningún caso deben interpretarse como contractuales. Consulte especificaciones técnicas y equipamiento de cada vehiculo en la red de concesionarios Oficiales Mercedes-Benz. Mercedes-Benz Argentina S.A.U se reserva el derecho de modificar especificaciones y/o nivel de equipamiento sin previo aviso y sin incurrir en ninguna obligación.</p>
      <p>Las imágenes son ilustrativas y no tienen ningún efecto contractual.</p>
    </div>
  </div>
</template>

<script setup lang="ts">
const appConfig = useAppConfig();
</script>

<style scope>
@import "~/assets/css/vans/legal.css";
</style>
