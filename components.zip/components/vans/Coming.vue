<template>
  <div id="coming">
    <div class="pageWidth">
      <div class="missing">Falta feedback</div>
    </div>
  </div>
</template>

<script setup lang="ts">
const appConfig = useAppConfig();
</script>

<style scope>
@import "~/assets/css/vans/coming.css";
</style>
